from setuptools import setup

setup(
        name = 'mhparse',
        version = '1.0',
        description = 'M/D(Yobi) to datetime.date parse',
        author = 'Akiyoshi Oda',
        author_email = 'akiyoshi.oda@gmail.com',
        py_modules=['mhparse'],
        )
